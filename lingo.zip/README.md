# lingo-opdracht
 
